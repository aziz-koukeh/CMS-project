-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2023 at 03:29 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogtest`
--
CREATE DATABASE IF NOT EXISTS `blogtest` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `blogtest`;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `post_id`, `parent_id`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES
(2, 2, 5, NULL, 'comments :......Sports is life', NULL, '2023-08-13 09:56:32', '2023-08-13 09:56:32'),
(3, 3, 10, NULL, 'comments :..Art', NULL, '2023-08-13 10:02:15', '2023-08-13 10:02:15'),
(4, 3, 9, NULL, 'comments :....Movie', NULL, '2023-08-13 10:02:45', '2023-08-13 10:02:45'),
(5, 3, 8, NULL, 'comments :.....Medicine', NULL, '2023-08-13 10:03:16', '2023-08-13 10:03:16'),
(6, 3, 7, NULL, 'comments :......Draw is lovly', NULL, '2023-08-13 10:03:49', '2023-08-13 10:03:49'),
(7, 3, 6, NULL, 'comments :.....Music is life', NULL, '2023-08-13 10:04:46', '2023-08-13 10:04:46'),
(8, 3, 5, NULL, 'comments :.....Sports is life', NULL, '2023-08-13 10:05:21', '2023-08-13 10:05:21'),
(9, 1, 12, NULL, 'comments :.......Design', NULL, '2023-08-13 10:06:58', '2023-08-13 10:06:58'),
(10, 1, 11, NULL, 'comments :.....Music && Movie', NULL, '2023-08-13 10:07:24', '2023-08-13 10:07:24'),
(11, 1, 10, NULL, 'comments :..Art', NULL, '2023-08-13 10:07:44', '2023-08-13 10:07:44'),
(12, 1, 9, NULL, '\"   comments :....Movie   \"', NULL, '2023-08-13 10:08:10', '2023-08-13 10:08:10'),
(13, 1, 8, NULL, '\"   comments :.....Medicine   \"', NULL, '2023-08-13 10:08:31', '2023-08-13 10:08:31'),
(14, 1, 7, NULL, '\"   comments :......Draw is lovly   \"', NULL, '2023-08-13 10:08:53', '2023-08-13 10:08:53'),
(16, 1, 6, 7, '6 minutes ago', NULL, '2023-08-13 10:11:37', '2023-08-13 10:11:37'),
(17, 4, 12, 9, '5 minutes ago', NULL, '2023-08-13 10:12:49', '2023-08-13 10:12:49'),
(18, 4, 11, 10, '5 minutes ago', NULL, '2023-08-13 10:13:11', '2023-08-13 10:13:11'),
(19, 4, 11, 10, '1 second ago', NULL, '2023-08-13 10:13:25', '2023-08-13 10:13:25'),
(20, 4, 6, NULL, 'comments :.....Music && Movie', NULL, '2023-08-13 10:13:59', '2023-08-13 10:13:59'),
(21, 4, 5, NULL, 'comments :......Sports is life', NULL, '2023-08-13 10:14:18', '2023-08-13 10:14:18'),
(22, 4, 5, 8, '8 minutes ago', NULL, '2023-08-13 10:14:30', '2023-08-13 10:14:30'),
(23, 4, 5, 2, '17 minutes ago', NULL, '2023-08-13 10:14:39', '2023-08-13 10:14:39'),
(24, 2, 9, NULL, 'comments :.....Music && Movie', NULL, '2023-08-13 10:15:28', '2023-08-13 10:15:28'),
(25, 2, 9, 4, '12 minutes ago', NULL, '2023-08-13 10:15:39', '2023-08-13 10:15:39'),
(26, 2, 9, 12, '7 minutes ago', NULL, '2023-08-13 10:15:46', '2023-08-13 10:15:46'),
(27, 2, 7, 6, '12 minutes ago', NULL, '2023-08-13 10:16:21', '2023-08-13 10:16:21'),
(28, 2, 7, 14, '7 minutes ago', NULL, '2023-08-13 10:16:30', '2023-08-13 10:16:30'),
(29, 2, 6, NULL, '\"   comments :.....Music && Movie   \"', NULL, '2023-08-13 10:27:21', '2023-08-13 10:27:21'),
(30, 4, 12, NULL, 'comments :.....Music && Movie', NULL, '2023-08-13 10:30:18', '2023-08-13 10:30:18'),
(31, 4, 12, NULL, 'comments ......Music is life', NULL, '2023-08-13 10:30:38', '2023-08-13 10:30:38'),
(32, 1, 5, 8, 'asas', NULL, '2023-08-13 15:46:51', '2023-08-13 15:46:51'),
(34, 29, 11, 10, 'comments :.....Music && Movie', NULL, '2023-08-14 07:48:58', '2023-08-14 07:48:58'),
(35, 29, 11, NULL, 'comments :.....Music && Movie', NULL, '2023-08-14 07:49:11', '2023-08-14 07:49:11');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2023_07_21_193031_create_profile_users', 1),
(5, '2023_07_22_092413_create_posts_table', 1),
(6, '2023_07_25_161808_create_tags_table', 1),
(7, '2023_07_27_084811_post_tag', 1),
(8, '2023_07_29_130639_create_comments_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `title`, `content`, `photo`, `slug`, `deleted_at`, `created_at`, `updated_at`) VALUES
(5, 1, 'Sports  is life', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1691930802.jpg', 'sports-is-life', NULL, '2023-08-13 09:46:42', '2023-08-13 15:47:26'),
(6, 1, 'Music  is life', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1692017176.jpg', 'music-is-life', NULL, '2023-08-13 09:47:43', '2023-08-14 09:46:16'),
(7, 2, 'Draw  is lovly', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1691931227.jpg', 'draw-is-lovly', NULL, '2023-08-13 09:53:47', '2023-08-13 09:53:47'),
(8, 2, 'Medicine', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1691931311.jpg', 'medicine', NULL, '2023-08-13 09:55:11', '2023-08-13 09:55:11'),
(9, 4, 'Movie', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1691931524.jpg', 'movie', NULL, '2023-08-13 09:58:44', '2023-08-13 09:58:44'),
(10, 4, 'Art', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1691931571.jpg', 'art', NULL, '2023-08-13 09:59:31', '2023-08-13 09:59:31'),
(11, 3, 'Music && Movie', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1691931673.jpg', 'music-movie', NULL, '2023-08-13 10:01:13', '2023-08-13 17:38:59'),
(12, 3, 'Design', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1691931708.jpg', 'design', NULL, '2023-08-13 10:01:48', '2023-08-13 10:01:48'),
(13, 1, 'Sport    Medicine    Movie    Music    Art    Draw    Design', 'Sport\r\n  \r\nMedicine\r\n  \r\nMovie\r\n  \r\nMusic\r\n  \r\nArt\r\n  \r\nDraw\r\n  \r\nDesign', 'uploads/posts/IMG_320_1691995178.jpg', 'sport-medicine-movie-music-art-draw-design', '2023-08-14 03:40:07', '2023-08-14 03:39:38', '2023-08-14 03:40:07'),
(15, 29, 'Sport', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1692016341.jpg', 'sport', NULL, '2023-08-14 07:56:24', '2023-08-14 09:32:21'),
(16, 29, 'Sport   Medicine', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard', 'uploads/posts/IMG_320_1692016364.jpg', 'sport-medicine', NULL, '2023-08-14 08:06:48', '2023-08-14 09:44:36');

-- --------------------------------------------------------

--
-- Table structure for table `post_tag`
--

CREATE TABLE `post_tag` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_tag`
--

INSERT INTO `post_tag` (`id`, `post_id`, `tag_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 2, 1, NULL, NULL),
(3, 3, 1, NULL, NULL),
(4, 4, 1, NULL, NULL),
(5, 5, 1, NULL, NULL),
(6, 6, 4, NULL, NULL),
(7, 6, 5, NULL, NULL),
(8, 7, 5, NULL, NULL),
(9, 7, 6, NULL, NULL),
(10, 8, 1, NULL, NULL),
(11, 8, 2, NULL, NULL),
(12, 9, 1, NULL, NULL),
(13, 9, 3, NULL, NULL),
(14, 9, 7, NULL, NULL),
(15, 10, 5, NULL, NULL),
(17, 11, 3, NULL, NULL),
(18, 11, 4, NULL, NULL),
(19, 12, 6, NULL, NULL),
(20, 12, 7, NULL, NULL),
(21, 5, 2, NULL, NULL),
(23, 10, 2, NULL, NULL),
(24, 5, 6, NULL, NULL),
(25, 13, 1, NULL, NULL),
(26, 14, 1, NULL, NULL),
(27, 15, 1, NULL, NULL),
(28, 16, 1, NULL, NULL),
(29, 16, 5, NULL, NULL),
(30, 6, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `profile_users`
--

CREATE TABLE `profile_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `bio` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '14',
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profile_users`
--

INSERT INTO `profile_users` (`id`, `country`, `gender`, `user_id`, `bio`, `facebook`, `phone`, `photo`, `created_at`, `updated_at`) VALUES
(1, 'Syria', 'Male', 1, 'hi !! I am new in this BLOGTEST', 'https://www.facebook.com', '+963995595413', 'uploads/profiles/IMG_320_Prf1691911218.jpg', '2023-08-11 15:04:17', '2023-08-13 04:20:18'),
(2, 'Syria', 'Male', 2, 'hi !! I am new in this BLOGTEST', 'https://www.facebook.com/Haderkoukeh', '+963995595413', 'uploads/profiles/IMG_320_Prf1691913438.jpg', '2023-08-11 15:06:12', '2023-08-13 17:25:54'),
(3, 'Syria', 'Male', 3, 'hi !! I am new in this BLOGTEST', 'https://www.facebook.com/jawadkoukeh', '+963995595413', 'uploads/profiles/IMG_320_Prf1691958567.jpg', '2023-08-11 15:25:46', '2023-08-13 17:29:27'),
(4, 'Syria', 'Male', 4, 'hi !! I am new in this BLOGTEST', 'https://www.facebook.com', '+963995595413', 'uploads/home/2.jpg', '2023-08-11 15:27:09', '2023-08-13 04:52:23'),
(24, 'Syria', 'Male', 29, 'hi !! I am new in this BlogTest', 'https://www.facebook.com/12345678', '+963995595413', 'uploads/profiles/IMG_320_Prf1692010395.jpg', '2023-08-14 07:47:32', '2023-08-14 08:48:45');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `tag`, `created_at`, `updated_at`) VALUES
(1, 'Sport', '2023-08-11 16:51:31', '2023-08-13 17:34:29'),
(2, 'Medicine', '2023-08-11 16:51:44', '2023-08-11 16:51:44'),
(3, 'Movie', '2023-08-11 16:51:52', '2023-08-11 16:51:52'),
(4, 'Music', '2023-08-11 16:52:00', '2023-08-11 16:52:00'),
(5, 'Art', '2023-08-11 16:52:20', '2023-08-11 16:52:20'),
(6, 'Draw', '2023-08-11 16:52:32', '2023-08-11 16:52:32'),
(7, 'Design', '2023-08-11 16:53:06', '2023-08-11 16:53:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int(10) UNSIGNED DEFAULT 2,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `level`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'abdul aziz koukeh', 1, 'abdulazizkoukeh@gmail.com', NULL, '$2y$10$8Clrq5btelAxaMOvaib8tO5BzY5/WQ6iZlb7P/LnQbgQmVzeIk1Ky', NULL, '2023-08-11 15:04:16', '2023-08-11 15:33:44'),
(2, 'hader koukeh', 2, 'hader@gmail.com', NULL, '$2y$10$wXfTdO46n7akfQvqqZdnyuUrIgiejHIf1dqB5VOSeHjqNo6727b9K', NULL, '2023-08-11 15:06:12', '2023-08-13 04:54:57'),
(3, 'jawad koukeh', 2, 'jawad@gmail.com', NULL, '$2y$10$G7mhvUKmriAQk5dMVg2Qp.nXYUVEI38l5zUSFyf2hOuKz0kHzf1/m', NULL, '2023-08-11 15:25:46', '2023-08-11 15:25:46'),
(4, 'wadood koukeh', 1, 'wadood@gmail.com', NULL, '$2y$10$fmvbn71TS1Nl1ifXBgwS5erb/zF8nK398Yce7UfFXCkDZDT3MT22S', NULL, '2023-08-11 15:27:08', '2023-08-11 15:27:08'),
(29, 'Ms. number', 1, '12345678@gmail.com', NULL, '$2y$10$lhpdGyCuMbUCaWpoCyHLmu8S1OFVaVKFgLwrUk0JdaakzaG7EyfOG', NULL, '2023-08-14 07:47:32', '2023-08-14 09:31:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_user_id_foreign` (`user_id`),
  ADD KEY `comments_post_id_foreign` (`post_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_user_id_foreign` (`user_id`);

--
-- Indexes for table `post_tag`
--
ALTER TABLE `post_tag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_users`
--
ALTER TABLE `profile_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profile_users_user_id_foreign` (`user_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `post_tag`
--
ALTER TABLE `post_tag`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `profile_users`
--
ALTER TABLE `profile_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `profile_users`
--
ALTER TABLE `profile_users`
  ADD CONSTRAINT `profile_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
